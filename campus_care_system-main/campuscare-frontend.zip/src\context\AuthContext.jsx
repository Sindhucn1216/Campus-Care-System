// Authentication and Demo Role Context
import React, { createContext, useContext, useState, useEffect } from 'react';
import { DEMO_USERS, USER_ROLES } from '../constants';

const AuthContext = createContext(null);
const AUTH_STORAGE_KEY = 'campuscare_current_user_v1';

export const AuthProvider = ({ children }) => {
  // Default to the first student demo user
  const [currentUser, setCurrentUser] = useState(() => {
    try {
      const saved = localStorage.getItem(AUTH_STORAGE_KEY);
      if (saved) return JSON.parse(saved);
      return DEMO_USERS[0]; // Aarav Sharma (Student)
    } catch {
      return DEMO_USERS[0];
    }
  });

  const [isLoading, setIsLoading] = useState(false);

  useEffect(() => {
    if (currentUser) {
      localStorage.setItem(AUTH_STORAGE_KEY, JSON.stringify(currentUser));
    } else {
      localStorage.removeItem(AUTH_STORAGE_KEY);
    }
  }, [currentUser]);

  // Quick switch role (vital for hackathon judge presentations)
  const switchRole = (role) => {
    const targetUser = DEMO_USERS.find((u) => u.role === role) || DEMO_USERS[0];
    setCurrentUser(targetUser);
    return targetUser;
  };

  const loginAsDemo = (role) => {
    return switchRole(role);
  };

  const login = async (email, password, selectedRole = USER_ROLES.STUDENT) => {
    setIsLoading(true);
    // Simulate brief network latency for realistic feel
    await new Promise((resolve) => setTimeout(resolve, 400));

    // Try finding existing demo user with this email, or generate a demo session
    let matched = DEMO_USERS.find((u) => u.email.toLowerCase() === email.toLowerCase());
    if (!matched) {
      matched = {
        id: `usr-${Date.now()}`,
        name: email.split('@')[0].replace('.', ' ').toUpperCase(),
        email,
        role: selectedRole,
        department: selectedRole === USER_ROLES.STAFF ? 'IT Support & Networks' : 'General Campus',
      };
    }

    setCurrentUser(matched);
    setIsLoading(false);
    return matched;
  };

  const register = async ({ name, email, role, department, rollNo, designation }) => {
    setIsLoading(true);
    await new Promise((resolve) => setTimeout(resolve, 500));

    const newUser = {
      id: `usr-${Date.now()}`,
      name,
      email,
      role: role || USER_ROLES.STUDENT,
      department: department || 'Campus Community',
      rollNo: rollNo || undefined,
      designation: designation || undefined,
      avatar: `https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&q=80&w=150`,
    };

    setCurrentUser(newUser);
    setIsLoading(false);
    return newUser;
  };

  const logout = () => {
    // Return to a guest or student demo
    setCurrentUser(null);
  };

  const updateProfile = (updatedFields) => {
    setCurrentUser((prev) => ({
      ...prev,
      ...updatedFields,
    }));
  };

  return (
    <AuthContext.Provider
      value={{
        currentUser,
        role: currentUser?.role || 'guest',
        isAuthenticated: !!currentUser,
        switchRole,
        loginAsDemo,
        login,
        register,
        logout,
        updateProfile,
        isLoading,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
