import React from 'react';
import { Routes, Route, Navigate, Link } from 'react-router-dom';
import MainLayout from '../components/layout/MainLayout';

// Pages
import LandingPage from '../pages/public/LandingPage';
import TrackingPage from '../pages/public/TrackingPage';
import LoginPage from '../pages/auth/LoginPage';
import RegisterPage from '../pages/auth/RegisterPage';
import StudentDashboard from '../pages/student/StudentDashboard';
import SubmitComplaintPage from '../pages/student/SubmitComplaintPage';
import MyComplaintsPage from '../pages/student/MyComplaintsPage';
import StaffDashboard from '../pages/staff/StaffDashboard';
import AdminDashboard from '../pages/admin/AdminDashboard';
import AdminComplaintsPage from '../pages/admin/AdminComplaintsPage';
import DepartmentManagementPage from '../pages/admin/DepartmentManagementPage';
import ComplaintDetailPage from '../pages/complaints/ComplaintDetailPage';
import ProfilePage from '../pages/profile/ProfilePage';

// 404 Component
const NotFoundPage = () => (
  <div className="max-w-md mx-auto px-4 py-20 text-center space-y-4">
    <div className="w-16 h-16 rounded-3xl bg-blue-50 text-blue-600 flex items-center justify-center mx-auto text-2xl font-bold font-mono">
      404
    </div>
    <h2 className="text-2xl font-bold text-campus-900">Page Not Found</h2>
    <p className="text-sm text-slate-500">
      The requested route does not exist on the CampusCare platform.
    </p>
    <Link
      to="/"
      className="inline-block px-5 py-2.5 rounded-xl bg-blue-600 hover:bg-blue-700 text-white text-xs font-semibold shadow-sm transition-all"
    >
      Return to Home
    </Link>
  </div>
);

export const AppRoutes = () => {
  return (
    <Routes>
      <Route element={<MainLayout />}>
        {/* Public Routes */}
        <Route path="/" element={<LandingPage />} />
        <Route path="/track" element={<TrackingPage />} />
        <Route path="/login" element={<LoginPage />} />
        <Route path="/register" element={<RegisterPage />} />

        {/* Student & Faculty Grievance Routes */}
        <Route path="/dashboard" element={<StudentDashboard />} />
        <Route path="/complaints" element={<MyComplaintsPage />} />
        <Route path="/complaints/new" element={<SubmitComplaintPage />} />
        <Route path="/complaints/:id" element={<ComplaintDetailPage />} />

        {/* Department Staff Routes */}
        <Route path="/staff/dashboard" element={<StaffDashboard />} />

        {/* Administrator Routes */}
        <Route path="/admin/dashboard" element={<AdminDashboard />} />
        <Route path="/admin/complaints" element={<AdminComplaintsPage />} />
        <Route path="/admin/departments" element={<DepartmentManagementPage />} />

        {/* Profile & Settings */}
        <Route path="/profile" element={<ProfilePage />} />

        {/* 404 Catch-All */}
        <Route path="*" element={<NotFoundPage />} />
      </Route>
    </Routes>
  );
};

export default AppRoutes;
