// Centralized API Service Layer
// Future-proofed for seamless integration with Node.js/Express + MySQL backend
// When VITE_USE_MOCK_DATA is 'true', requests route through the client mock repository

import { complaintService as mockService } from '../mock/complaintService';

const API_BASE_URL = import.meta.env.VITE_API_BASE_URL || 'http://localhost:3000/api';
const USE_MOCK = import.meta.env.VITE_USE_MOCK_DATA !== 'false';

// Helper for real HTTP requests when backend is active
async function request(endpoint, options = {}) {
  const token = localStorage.getItem('campuscare_auth_token');
  const headers = {
    'Content-Type': 'application/json',
    ...(token ? { Authorization: `Bearer ${token}` } : {}),
    ...options.headers,
  };

  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      ...options,
      headers,
    });

    const data = await response.json().catch(() => null);

    if (!response.ok) {
      throw new Error(data?.message || `HTTP error ${response.status}: ${response.statusText}`);
    }

    return data;
  } catch (error) {
    console.error(`[API Error] ${endpoint}:`, error);
    throw error;
  }
}

export const api = {
  // Complains API
  complaints: {
    list: async (filters) => {
      if (USE_MOCK) return mockService.listComplaints(filters);
      const query = new URLSearchParams(filters).toString();
      return request(`/complaints?${query}`);
    },

    getById: async (id) => {
      if (USE_MOCK) return mockService.getComplaintById(id);
      return request(`/complaints/${id}`);
    },

    create: async (data, reporter) => {
      if (USE_MOCK) return mockService.createComplaint(data, reporter);
      return request('/complaints', {
        method: 'POST',
        body: JSON.stringify(data),
      });
    },

    updateStatus: async (id, status, note, user, resolutionNotes) => {
      if (USE_MOCK) return mockService.updateComplaintStatus(id, status, note, user, resolutionNotes);
      return request(`/complaints/${id}/status`, {
        method: 'PATCH',
        body: JSON.stringify({ status, note, resolutionNotes }),
      });
    },

    assign: async (id, departmentId, staffId, note, user) => {
      if (USE_MOCK) return mockService.assignComplaint(id, departmentId, staffId, note, user);
      return request(`/complaints/${id}/assign`, {
        method: 'PATCH',
        body: JSON.stringify({ departmentId, staffId, note }),
      });
    },

    updatePriority: async (id, priority, user) => {
      if (USE_MOCK) return mockService.updatePriority(id, priority, user);
      return request(`/complaints/${id}/priority`, {
        method: 'PATCH',
        body: JSON.stringify({ priority }),
      });
    },

    submitFeedback: async (id, feedback) => {
      if (USE_MOCK) return mockService.submitFeedback(id, feedback);
      return request(`/complaints/${id}/feedback`, {
        method: 'POST',
        body: JSON.stringify(feedback),
      });
    },
  },

  // Departments API
  departments: {
    list: async () => {
      if (USE_MOCK) return mockService.listDepartments();
      return request('/departments');
    },

    create: async (data) => {
      if (USE_MOCK) return mockService.createDepartment(data);
      return request('/departments', {
        method: 'POST',
        body: JSON.stringify(data),
      });
    },

    update: async (id, updates) => {
      if (USE_MOCK) return mockService.updateDepartment(id, updates);
      return request(`/departments/${id}`, {
        method: 'PATCH',
        body: JSON.stringify(updates),
      });
    },
  },

  // Analytics API
  analytics: {
    getDashboard: async (departmentId) => {
      if (USE_MOCK) return mockService.getDashboardAnalytics(departmentId);
      const query = departmentId ? `?departmentId=${departmentId}` : '';
      return request(`/admin/analytics${query}`);
    },
  },

  // Mock resets
  resetMockData: () => {
    return mockService.resetToDefault();
  },
};
