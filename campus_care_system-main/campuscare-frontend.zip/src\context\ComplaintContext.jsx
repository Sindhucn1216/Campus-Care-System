// Reactive Global Store for Complaints & Departments
import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { api } from '../services/api/apiClient';
import { useAuth } from './AuthContext';
import { useToast } from './ToastContext';

const ComplaintContext = createContext(null);

export const ComplaintProvider = ({ children }) => {
  const { currentUser } = useAuth();
  const { showToast } = useToast();

  const [complaints, setComplaints] = useState([]);
  const [departments, setDepartments] = useState([]);
  const [analytics, setAnalytics] = useState(null);
  const [loading, setLoading] = useState(true);

  // Load all data
  const refreshData = useCallback(async () => {
    try {
      setLoading(true);
      const [complaintsList, deptsList, analyticsData] = await Promise.all([
        api.complaints.list({}),
        api.departments.list(),
        api.analytics.getDashboard(),
      ]);

      setComplaints(complaintsList);
      setDepartments(deptsList);
      setAnalytics(analyticsData);
    } catch (err) {
      console.error('Error refreshing complaint data:', err);
      showToast({
        title: 'Data Load Error',
        message: err.message || 'Could not fetch records.',
        type: 'error',
      });
    } finally {
      setLoading(false);
    }
  }, [showToast]);

  useEffect(() => {
    refreshData();
  }, [refreshData]);

  // Submit a new complaint
  const createNewComplaint = async (formData) => {
    try {
      const created = await api.complaints.create(formData, currentUser);
      await refreshData();
      showToast({
        title: 'Complaint Registered Successfully',
        message: `Assigned ID ${created.complaintCode}. You can track it anytime.`,
        type: 'success',
      });
      return created;
    } catch (err) {
      showToast({
        title: 'Submission Failed',
        message: err.message || 'Validation error while submitting complaint.',
        type: 'error',
      });
      throw err;
    }
  };

  // Update Status
  const changeComplaintStatus = async (id, newStatus, note, resolutionNotes) => {
    try {
      const updated = await api.complaints.updateStatus(id, newStatus, note, currentUser, resolutionNotes);
      await refreshData();
      showToast({
        title: 'Status Updated',
        message: `Complaint status marked as ${newStatus}.`,
        type: 'success',
      });
      return updated;
    } catch (err) {
      showToast({
        title: 'Status Update Failed',
        message: err.message,
        type: 'error',
      });
      throw err;
    }
  };

  // Assign Department & Staff
  const assignDepartmentToComplaint = async (id, departmentId, staffId, note) => {
    try {
      const updated = await api.complaints.assign(id, departmentId, staffId, note, currentUser);
      await refreshData();
      showToast({
        title: 'Department Assigned',
        message: `Complaint reassigned to ${updated.departmentName}.`,
        type: 'success',
      });
      return updated;
    } catch (err) {
      showToast({
        title: 'Assignment Failed',
        message: err.message,
        type: 'error',
      });
      throw err;
    }
  };

  // Update Priority
  const updateComplaintPriority = async (id, priority) => {
    try {
      const updated = await api.complaints.updatePriority(id, priority, currentUser);
      await refreshData();
      showToast({
        title: 'Priority Updated',
        message: `Ticket priority escalated to ${priority}.`,
        type: 'info',
      });
      return updated;
    } catch (err) {
      showToast({
        title: 'Update Failed',
        message: err.message,
        type: 'error',
      });
      throw err;
    }
  };

  // Feedback Submission
  const submitComplaintFeedback = async (complaintId, { rating, comments }) => {
    try {
      const updated = await api.complaints.submitFeedback(complaintId, {
        rating,
        comments,
        userId: currentUser?.id,
        userName: currentUser?.name,
      });
      await refreshData();
      showToast({
        title: 'Feedback Recorded',
        message: `Thank you for rating our resolution (${rating} stars).`,
        type: 'success',
      });
      return updated;
    } catch (err) {
      showToast({
        title: 'Feedback Error',
        message: err.message,
        type: 'error',
      });
      throw err;
    }
  };

  // Add Department
  const addNewDepartment = async (deptData) => {
    try {
      const created = await api.departments.create(deptData);
      await refreshData();
      showToast({
        title: 'Department Created',
        message: `${created.name} is now available for routing grievances.`,
        type: 'success',
      });
      return created;
    } catch (err) {
      showToast({
        title: 'Creation Failed',
        message: err.message,
        type: 'error',
      });
      throw err;
    }
  };

  // Toggle Department Active
  const toggleDepartmentStatus = async (id, currentStatus) => {
    try {
      const updated = await api.departments.update(id, { active: !currentStatus });
      await refreshData();
      showToast({
        title: updated.active ? 'Department Activated' : 'Department Deactivated',
        message: `${updated.name} status updated.`,
        type: 'info',
      });
      return updated;
    } catch (err) {
      showToast({
        title: 'Action Failed',
        message: err.message,
        type: 'error',
      });
      throw err;
    }
  };

  // Reset demo data
  const resetDemo = () => {
    api.resetMockData();
    refreshData();
    showToast({
      title: 'Demo Data Reset',
      message: 'Initial realistic campus complaints restored.',
      type: 'info',
    });
  };

  return (
    <ComplaintContext.Provider
      value={{
        complaints,
        departments,
        analytics,
        loading,
        refreshData,
        createNewComplaint,
        changeComplaintStatus,
        assignDepartmentToComplaint,
        updateComplaintPriority,
        submitComplaintFeedback,
        addNewDepartment,
        toggleDepartmentStatus,
        resetDemo,
      }}
    >
      {children}
    </ComplaintContext.Provider>
  );
};

export const useComplaints = () => {
  const context = useContext(ComplaintContext);
  if (!context) {
    throw new Error('useComplaints must be used within a ComplaintProvider');
  }
  return context;
};
